
let size = 50;

function setup(){
   createCanvas(500, 500);
   background(255);
}

function draw(){
   noFill();
   ellipse(mouseX, mouseY, size, size);
   //increment x by 3 every frame
	size+=3;
	//keep size between 0 and 99
	size = size % 100;
	// Use modulus for x or y values?
} 

//this coding is that it continuosly draws a circle from 0-99 in size 
//by every frame.


////////////////
/*
let x = 0;
let y = 100;
let size = 30; 
let speed = 2;
let score = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  // Move the circle
  fill(0,255,0);
  circle(x, y, size);
  x = x % width;
  x+=speed;

  // The mouse
  fill(255,0,0);
  circle(mouseX, mouseY, size);

  // The score
  textSize(20);
  text(score, 30, 30);
}

function mouseClicked(){
  let distance = dist(x, y, mouseX, mouseY); 
  if(distance <= size/2){
    score++;
  }
}
*/