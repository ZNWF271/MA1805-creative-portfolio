let row = 1;     // Number of shapes in a row
let col = 100;     // Number of shapes in a col
let pad = 5;      // Padding between shapes 
let sWidth, sHeight;  
let rgba = [80, 200, 130, 255];     

function setup() {
    createCanvas(windowWidth, windowHeight);
    sWidth = (width/col)-(pad+(pad/col));
    sHeight = (height/row)-(pad+(pad/row));
    rectMode(CENTER);
    noStroke();
}

function draw(){
  background(200); 
  for(let i=0; i<row; i++){
    for(let ii=0; ii<col; ii++){
      let x = pad+(ii*sWidth)+(pad*ii)+(sWidth/2);
      let y = pad+(i*sHeight)+(pad*i)+(sHeight/2);
      fill(rgba); 
      rect(x, y, sWidth, sHeight); 
      rotateRect(2);
      push(2);
        angleMode(DEGREES)
        translate(x, y);
        rotate(i*1); 
        rotate(millis() / 200 * PI / 2);
        rect(x, y, sWidth, sHeight); 
      pop(); 
    }
  }
}
