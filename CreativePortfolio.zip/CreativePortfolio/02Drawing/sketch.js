

function setup() {
  createCanvas(400,400);
}

function draw() {
  background(150, 20, 100);

   
    circle(200, 200, 400)
  fill(306, 60, 130)
  stroke(216, 196, 71)
  strokeWeight(30)

 
  circle(200, 150, 300)
  fill(20, 100, 13)
  stroke(216, 196, 71)
  strokeWeight(30)
  

  circle(200, 250, 300)
  fill(20, 100, 13)
  stroke(216, 196, 71)
  strokeWeight(30)
  

  circle(200, 200, 300)
  fill(36, 100, 123)
  stroke(216, 196, 71)
  strokeWeight(30)


  circle(200, 200, 200)
fill(36,200,450)
stroke(216,196,71)
strokeWeight(30)
  

circle(200, 200, 100)
fill(36,200,450)
stroke(216,196,71)
strokeWeight(30)


circle(200, 200, 10)
fill(36,200,450)
stroke(216,196,71)
strokeWeight(30)
}
