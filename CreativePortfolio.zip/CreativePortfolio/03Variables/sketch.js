/* these global variable are 
available to all functions because 
they are placed outside other 
functions in the sketch!
*/
let xVal = 100;
let yVal = 100;

function setup() {
  let myWidth = 640; 
	createCanvas(myWidth,480);
	// We can access myWidth
	// We can access xVal and yVal
}

function draw() {
	let mySize = 50; 
	background(255,0,100); 
	ellipse(xVal, yVal, mySize); 
	// We can't access myWidth
	// We can access xVal and yVal
	// we can access mySize
}


 