
let x = 100;
let y = 0;
let size = 30; 
let speed = 1;
let score = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  // Move the circle
  fill(400,255,10);
  circle(x, y, size);
  x = x % width;
  y+=speed;

  fill(400,255,10);
  circle(x+200, y, size);
  x = x % width;
  y+=speed; 

  fill(400,255,10);
  circle(x+50, y, size);
  x = x % width;
  y+=speed;


  // The mouse
  fill(255,0,0);
  circle(mouseX, mouseY, size);

  // The score
  textSize(20);
  text(score, 30, 30);
}

function mouseClicked(){
  let distance = dist(x, y, mouseX, mouseY); 
  if(distance <= size/2){
    score++;
  }
}
