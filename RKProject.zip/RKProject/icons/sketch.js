let img; 

function preload() {
  img = loadImage('XXXX'); // Load image
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0, 255, 0);
}

function draw() {
  image(img, 0, 100, img.width/2, 400);
}
